import os, json, secrets, hashlib, subprocess, datetime
from pathlib import Path
from functools import wraps
from flask import Flask, request, redirect, url_for, session, render_template_string, flash

APP_ROOT = Path(r"D:\honeypot-deploy")
LOG_DIR  = APP_ROOT / "data" / "logs"
USERS_DB = APP_ROOT / "data" / "users.json"
AUDIT    = APP_ROOT / "data" / "audit.log"

app = Flask(__name__)
app.secret_key = os.environ.get("HONEY_UI_SECRET", "change-me-please")

# ---------- auth helpers ----------
def _pbkdf2_hash(pw: str, salt_hex: str, rounds: int = 200_000) -> str:
    salt = bytes.fromhex(salt_hex)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, rounds)
    return h.hex()

def ensure_admin():
    if not USERS_DB.exists():
        salt = secrets.token_hex(16)
        default_pw = "Admin@123"
        data = {
            "admin": {
                "salt": salt,
                "hash": _pbkdf2_hash(default_pw, salt),
                "role": "admin"
            }
        }
        USERS_DB.parent.mkdir(parents=True, exist_ok=True)
        USERS_DB.write_text(json.dumps(data, indent=2), encoding="utf-8")
        AUDIT.write_text(f"{datetime.datetime.utcnow()}Z init admin default password\n", encoding="utf-8")

def load_users():
    if USERS_DB.exists():
        return json.loads(USERS_DB.read_text(encoding="utf-8"))
    return {}

def save_users(u):
    USERS_DB.write_text(json.dumps(u, indent=2), encoding="utf-8")

def login_required(f):
    @wraps(f)
    def w(*a, **kw):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **kw)
    return w

def role_required(role):
    def deco(f):
        @wraps(f)
        def w(*a, **kw):
            if session.get("role") != role:
                flash("لا تملك الصلاحية", "warning")
                return redirect(url_for("index"))
            return f(*a, **kw)
        return w
    return deco

# ---------- docker helpers ----------
def docker_cmd(args):
    # يشغّل docker CLI ويعيد (returncode, stdout, stderr)
    p = subprocess.run(["docker", *args], capture_output=True, text=True, shell=False)
    return p.returncode, p.stdout.strip(), p.stderr.strip()

def container_status():
    rc, out, err = docker_cmd(["ps", "-a", "--filter", "name=basic-honeypot", "--format", "{{.Status}}"])
    return out or "not found"

def start_container():
    # حذف أي نسخة قديمة ثم تشغيل بضوابط أمان
    docker_cmd(["rm", "-f", "basic-honeypot"])
    args = [
        "run","-d","--name","basic-honeypot",
        "--read-only","--tmpfs","/tmp:rw","--cap-drop","ALL",
        "--security-opt","no-new-privileges","--pids-limit","100","--memory","256m","--cpus","0.5",
        "-p","127.0.0.1:2222:22","-p","127.0.0.1:8080:80",
        "-v", str(LOG_DIR)+":/var/log/honeypot:rw",
        "basic-honeypot"
    ]
    return docker_cmd(args)

def stop_container():
    return docker_cmd(["rm","-f","basic-honeypot"])

def tail(path: Path, n=200):
    if not path.exists(): return ""
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    return "\n".join(lines[-n:])

# ---------- routes ----------
TPL_BASE = """
<!doctype html><html lang="ar"><head>
<meta charset="utf-8"><title>Honeypot Panel</title>
<style>
body{font-family:sans-serif;background:#0b0d10;color:#e6e6e6;margin:20px;}
a,button{background:#1f2937;color:#fff;border:none;padding:8px 14px;border-radius:8px;cursor:pointer;text-decoration:none}
button:hover,a:hover{background:#374151}
.card{background:#111827;border:1px solid #1f2937;border-radius:12px;padding:16px;margin-bottom:14px}
input,select{padding:6px 10px;border-radius:6px;border:1px solid #334155;background:#0b0d10;color:#e6e6e6}
.table{width:100%;border-collapse:collapse}
.table td,.table th{border-bottom:1px solid #1f2937;padding:6px 8px;text-align:right}
.flash{padding:8px 10px;border-radius:8px;margin:10px 0;background:#334155}
.nav a{margin-left:8px}
pre{white-space:pre-wrap;word-wrap:break-word;background:#0b0d10;border:1px solid #1f2937;border-radius:8px;padding:10px}
</style></head><body>
<div class="nav">
  {% if session.get('user') %}
    مرحبًا {{session.get('user')}} — دورك: {{session.get('role')}} |
    <a href="{{url_for('index')}}">الرئيسية</a>
    <a href="{{url_for('logs')}}">اللوقات</a>
    {% if session.get('role') == 'admin' %}
    <a href="{{url_for('users')}}">المستخدمون</a>
    {% endif %}
    <a href="{{url_for('logout')}}">خروج</a>
  {% endif %}
</div>
{% with messages = get_flashed_messages(with_categories=true) %}
  {% for cat,msg in messages %}<div class="flash">{{msg}}</div>{% endfor %}
{% endwith %}
<div class="content">
  {{ body|safe }}
</div></body></html>
"""

@app.route("/login", methods=["GET","POST"])
def login():
    ensure_admin()
    if request.method=="POST":
        users = load_users()
        u = users.get(request.form["username"])
        if u:
            if _pbkdf2_hash(request.form["password"], u["salt"]) == u["hash"]:
                session["user"]=request.form["username"]
                session["role"]=u.get("role","operator")
                AUDIT.open("a",encoding="utf-8").write(f"{datetime.datetime.utcnow()}Z UI login {session['user']}\n")
                return redirect(url_for("index"))
        flash("بيانات الدخول غير صحيحة","danger")
    body = """
    <div class="card" style="max-width:420px;margin:auto">
      <h3>تسجيل الدخول</h3>
      <form method="post">
        <div><label>المستخدم</label><br><input name="username" required></div>
        <div><label>كلمة المرور</label><br><input type="password" name="password" required></div>
        <div style="margin-top:8px"><button type="submit">دخول</button></div>
        <div style="margin-top:8px;color:#9ca3af">افتراضيًا: admin / Admin@123 — غيّرها بعد الدخول.</div>
      </form>
    </div>
    """
    return render_template_string(TPL_BASE, body=body)

@app.route("/logout")
def logout():
    if session.get("user"):
        AUDIT.open("a",encoding="utf-8").write(f"{datetime.datetime.utcnow()}Z UI logout {session['user']}\n")
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    st = container_status()
    body = f"""
    <div class="card">
      <h3>حالة الحاوية</h3>
      <p>basic-honeypot: <b>{st}</b></p>
      {% if session.get('role') == 'admin' %}
      <form method="post" action="{{url_for('do_start')}}" style="display:inline"><button>تشغيل</button></form>
      <form method="post" action="{{url_for('do_stop')}}"  style="display:inline"><button>إيقاف</button></form>
      {% endif %}
      <a href="http://127.0.0.1:8080" target="_blank">فتح صفحة الهوني بوت</a>
    </div>
    <div class="card">
      <h3>أحدث سطور من all.log</h3>
      <pre>{{ last|safe }}</pre>
    </div>
    """
    last = tail(LOG_DIR/"all.log", 50)
    return render_template_string(TPL_BASE, body=body, last=last)

@app.route("/start", methods=["POST"])
@login_required @role_required("admin")
def do_start():
    rc,out,err = start_container()
    AUDIT.open("a",encoding="utf-8").write(f"{datetime.datetime.utcnow()}Z start {session['user']} rc={rc} {err}\n")
    flash("تم طلب التشغيل","info")
    return redirect(url_for("index"))

@app.route("/stop", methods=["POST"])
@login_required @role_required("admin")
def do_stop():
    rc,out,err = stop_container()
    AUDIT.open("a",encoding="utf-8").write(f"{datetime.datetime.utcnow()}Z stop {session['user']} rc={rc} {err}\n")
    flash("تم طلب الإيقاف","info")
    return redirect(url_for("index"))

@app.route("/logs")
@login_required
def logs():
    http = tail(LOG_DIR/"http.log", 200)
    ssh  = tail(LOG_DIR/"sshd.log", 200)
    body = """
    <div class="card"><h3>HTTP</h3><pre>{{http}}</pre></div>
    <div class="card"><h3>SSH</h3><pre>{{ssh}}</pre></div>
    """
    return render_template_string(TPL_BASE, body=body, http=http, ssh=ssh)

@app.route("/users", methods=["GET","POST"])
@login_required @role_required("admin")
def users():
    users = load_users()
    if request.method=="POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        role = request.form.get("role","operator")
        if username in users:
            flash("المستخدم موجود","warning")
        else:
            salt = secrets.token_hex(16)
            users[username] = {"salt":salt, "hash":_pbkdf2_hash(password,salt), "role":role}
            save_users(users)
            flash("تمت إضافة المستخدم","success")
    rows = "".join([f"<tr><td>{u}</td><td>{v.get('role')}</td></tr>" for u,v in users.items()])
    body = f"""
    <div class="card">
      <h3>المستخدمون</h3>
      <table class="table"><tr><th>المستخدم</th><th>الدور</th></tr>{rows}</table>
      <h4>إضافة مستخدم</h4>
      <form method="post">
        <div><input name="username" placeholder="username" required></div>
        <div><input name="password" type="password" placeholder="password" required></div>
        <div>
          <select name="role">
            <option value="operator">operator</option>
            <option value="admin">admin</option>
          </select>
        </div>
        <div style="margin-top:8px"><button type="submit">إضافة</button></div>
      </form>
    </div>
    """
    return render_template_string(TPL_BASE, body=body)
# أي routes فوق

@app.route("/ssh")
@login_required
def ssh_logs():
    ssh_lines = tail(LOG_DIR / "sshd.log", 200)
    return render_template("ssh.html", logs=ssh_lines)

# 👇 حط هذا هنا
@app.route("/honeypot")
@login_required
def honeypot_page():
    ssh_lines = tail(LOG_DIR / "sshd.log", 200)
    status = container_status()
    return render_template("honeypot.html", logs=ssh_lines, status=status)
  
if __name__ == "__main__":
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ensure_admin()
    app.run(host="127.0.0.1", port=5001, debug=False)
