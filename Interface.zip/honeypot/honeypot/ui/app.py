# app.py
import os, re, json, secrets, hashlib, subprocess, datetime
from pathlib import Path
from collections import Counter, deque
from functools import wraps
from flask import Flask, request, redirect, url_for, session, render_template, flash, jsonify
from dotenv import load_dotenv

# --- Environment setup ---
load_dotenv()
BASE = Path(r"D:\honeypot")
LOG_DIR = BASE / "logs"
UI_DIR = BASE / "ui"
USERS_FILE = UI_DIR / "users.json"
AUDIT_FILE = UI_DIR / "audit.log"

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.getenv("HONEY_UI_SECRET", secrets.token_hex(16))

# --- Password hashing ---
def _pbkdf2_hash(pw: str, salt_hex: str, rounds: int = 200_000) -> str:
    salt = bytes.fromhex(salt_hex)
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, rounds).hex()

# --- Admin user initialization ---
def ensure_admin():
    """Ensure valid admin user file exists"""
    USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if USERS_FILE.exists():
        try:
            data = json.loads(USERS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "admin" in data:
                return
        except Exception:
            pass

    salt = secrets.token_hex(16)
    default_pw = "Admin@123"
    users = {
        "admin": {
            "salt": salt,
            "hash": _pbkdf2_hash(default_pw, salt),
            "role": "admin",
            "created_at": datetime.datetime.utcnow().isoformat()
        }
    }
    USERS_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    AUDIT_FILE.write_text(f"{datetime.datetime.utcnow().isoformat()}Z init admin default\n", encoding="utf-8")


# --- User helpers ---
def load_users():
    if not USERS_FILE.exists():
        return {}
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except:
        return {}

def save_users(users):
    USERS_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")

def audit(msg: str):
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.utcnow().isoformat()}] {msg}\n")

# --- Logs ---
def tail_file(path: Path, n=200):
    if not path.exists(): return []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return list(deque(f, maxlen=n))

def top_ips_from_log(lines, top_n=10):
    ips = re.findall(r'(\d{1,3}(?:\.\d{1,3}){3})', "\n".join(lines))
    return Counter(ips).most_common(top_n)

# --- Docker ---
def docker_cmd(args):
    p = subprocess.run(["docker", *args], capture_output=True, text=True)
    return p.returncode, p.stdout.strip(), p.stderr.strip()

def container_status():
    rc, out, err = docker_cmd(["ps", "-a", "--filter", "name=basic-honeypot", "--format", "{{.Status}}"])
    return out or "stopped"

def start_container():
    docker_cmd(["rm", "-f", "basic-honeypot"])
    args = [
        "run","-d","--name","basic-honeypot",
        "--read-only","--tmpfs","/tmp:rw","--cap-drop","ALL",
        "--security-opt","no-new-privileges","--pids-limit","100","--memory","256m","--cpus","0.5",
        "-p","127.0.0.1:2222:22","-p","127.0.0.1:8080:80",
        "-v", str(LOG_DIR)+":/var/log/honeypot:rw","basic-honeypot"
    ]
    return docker_cmd(args)

def stop_container():
    return docker_cmd(["rm","-f","basic-honeypot"])

# --- Auth ---
def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **kw)
    return wrapper

def role_required(role):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            if session.get("role") != role:
                flash("No permission", "warning")
                return redirect(url_for("dashboard"))
            return f(*a, **kw)
        return wrapper
    return deco

# --- Routes ---
@app.route("/login", methods=["GET","POST"])
def login():
    ensure_admin()
    if request.method == "POST":
        users = load_users()
        username = request.form["username"]
        password = request.form["password"]

        user = users.get(username)
        if user and _pbkdf2_hash(password, user["salt"]) == user["hash"]:
            session["user"] = username
            session["role"] = user.get("role", "operator")
            audit(f"ui_login {username}")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    audit(f"ui_logout {session.get('user')}")
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    st = container_status()
    lines = tail_file(LOG_DIR / "all.log", 200)
    top_ips = top_ips_from_log(lines)
    return render_template("dashboard.html", status=st, logs=lines, top_ips=top_ips, role=session.get("role"))

@app.route("/start", methods=["POST"])
@login_required
@role_required("admin")
def start():
    rc, out, err = start_container()
    audit(f"start by {session['user']} rc={rc}")
    flash("Container started", "info")
    return redirect(url_for("dashboard"))

@app.route("/stop", methods=["POST"])
@login_required
@role_required("admin")
def stop():
    rc, out, err = stop_container()
    audit(f"stop by {session['user']} rc={rc}")
    flash("Container stopped", "info")
    return redirect(url_for("dashboard"))

@app.route("/users", methods=["GET", "POST"])
@login_required
@role_required("admin")
def users_page():
    users = load_users()
    if not isinstance(users, dict):
        users = {}

    # ----- ADD USER -----
    if request.method == "POST" and "add_user" in request.form:
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "operator")

        if not username or not password:
            flash("Please fill all fields", "warning")
            return redirect(url_for("users_page"))

        if username in users:
            flash("User already exists", "danger")
        else:
            salt = secrets.token_hex(16)
            users[username] = {
                "salt": salt,
                "hash": _pbkdf2_hash(password, salt),
                "role": role,
                "created_at": datetime.datetime.utcnow().isoformat()
            }
            save_users(users)
            audit(f"user_added {username} by {session.get('user')}")
            flash(f"✅ User {username} added successfully!", "success")
            return redirect(url_for("users_page"))

    # ----- REMOVE USER -----
    if request.method == "POST" and "remove_user" in request.form:
        username = request.form.get("remove_user")
        if username == "admin":
            flash("🚫 You cannot delete the default admin!", "danger")
        elif username in users:
            del users[username]
            save_users(users)
            audit(f"user_deleted {username} by {session.get('user')}")
            flash(f"🗑 User {username} deleted successfully.", "info")
        else:
            flash("User not found.", "warning")
        return redirect(url_for("users_page"))

    # ----- LOAD LOGS -----
    logs = tail_file(AUDIT_FILE, 50)
    return render_template("users.html", users=users, logs=logs)



@app.route("/api/top_ips")
@login_required
def api_top_ips():
    lines = tail_file(LOG_DIR / "all.log", 2000)
    return jsonify({"top": top_ips_from_log(lines, 20)})

@app.route("/api/audit_logs")
@login_required
def api_audit_logs():
    lines = tail_file(AUDIT_FILE, 50)
    return jsonify({"logs": lines})


if __name__ == "__main__":
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ensure_admin()
    app.run(host="127.0.0.1", port=5001, debug=False)
