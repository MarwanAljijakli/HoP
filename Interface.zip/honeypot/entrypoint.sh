#!/bin/sh
echo "Honeypot starting..."

WEBROOT="/home/admin/webroot"
mkdir -p "${WEBROOT}"
echo "<html><body><h1>Basic Honeypot</h1><p>Welcome!</p></body></html>" > "${WEBROOT}/index.html"
chown -R admin:admin "${WEBROOT}"

/usr/sbin/sshd -D &
cd "${WEBROOT}"
python3 -m http.server 80
